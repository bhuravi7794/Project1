const landingData = {
  appName: "UST Connector",
  signUP: "signup",
  login: "login",
};

export default landingData;
