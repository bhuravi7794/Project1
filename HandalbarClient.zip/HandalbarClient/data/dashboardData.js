const actionData = {
  editProfile: "Edit Profile",
  addExperience: "Add Experience",
  addEducation: "Add Eduction",
};

const dashboardData = {
  profile: null,
  createProfile: "Create Profile",
};

export { actionData, dashboardData };
