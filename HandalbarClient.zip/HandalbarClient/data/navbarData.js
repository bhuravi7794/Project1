const navbarData = {
  homeUrl: "/",
  title: "UST Connector",
  developers: "developers",
  register: "register",
  login: "login",
};

export default navbarData;
