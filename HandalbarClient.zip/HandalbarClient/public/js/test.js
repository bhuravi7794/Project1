console.log("hello from script");
